"""Runtime settings stored in the ``app_settings`` table.

Only keys listed in ``RUNTIME_OVERRIDABLE`` can be changed. Values are validated by
building a full ``Settings`` model, so the same constraints apply as for ``.env``.
"""

from __future__ import annotations

from typing import Any

from pydantic import ValidationError as PydanticValidationError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import RUNTIME_OVERRIDABLE, Settings
from app.db.models import AppSetting
from app.services.errors import ValidationError

_TRUE = {"1", "true", "on", "yes", "да", "вкл", "включить", "y"}
_FALSE = {"0", "false", "off", "no", "нет", "выкл", "выключить", "n"}


def parse_value(key: str, raw: str) -> Any:
    kind = RUNTIME_OVERRIDABLE.get(key)
    if kind is None:
        raise ValidationError("Эту настройку нельзя менять из бота")
    text = raw.strip()
    if kind is bool:
        low = text.lower()
        if low in _TRUE:
            return True
        if low in _FALSE:
            return False
        raise ValidationError("Введите «вкл» или «выкл»")
    if kind is int:
        if not text.lstrip("-").isdigit():
            raise ValidationError("Нужно целое число")
        return int(text)
    return text


def format_value(value: Any) -> str:
    if isinstance(value, bool):
        return "вкл" if value else "выкл"
    if value is None or value == "":
        return "—"
    return str(value)


class RuntimeSettingsStore:
    def __init__(self, base: Settings) -> None:
        self._base = base
        self._cache: dict[str, Any] | None = None

    @property
    def base(self) -> Settings:
        return self._base

    def invalidate(self) -> None:
        self._cache = None

    async def overrides(self, session: AsyncSession) -> dict[str, Any]:
        if self._cache is None:
            result = await session.execute(select(AppSetting))
            loaded: dict[str, Any] = {}
            for row in result.scalars().all():
                if row.key in RUNTIME_OVERRIDABLE and isinstance(row.value, dict):
                    loaded[row.key] = row.value.get("v")
            self._cache = loaded
        return dict(self._cache)

    async def effective(self, session: AsyncSession) -> Settings:
        overrides = await self.overrides(session)
        return self._base.with_overrides(overrides)

    async def set(self, session: AsyncSession, *, key: str, raw: str, admin_id: int) -> Any:
        value = parse_value(key, raw)
        current = await self.overrides(session)
        candidate = {**current, key: value}
        _validate(self._base, candidate)
        row = await session.get(AppSetting, key)
        if row is None:
            row = AppSetting(key=key, value={"v": value}, updated_by=admin_id)
            session.add(row)
        else:
            row.value = {"v": value}
            row.updated_by = admin_id
        await session.flush()
        self._cache = candidate
        return value

    async def reset(self, session: AsyncSession, *, key: str) -> None:
        if key not in RUNTIME_OVERRIDABLE:
            raise ValidationError("Эту настройку нельзя менять из бота")
        row = await session.get(AppSetting, key)
        if row is not None:
            await session.delete(row)
            await session.flush()
        if self._cache is not None:
            self._cache.pop(key, None)

    def default_value(self, key: str) -> Any:
        return getattr(self._base, key)


def _validate(base: Settings, overrides: dict[str, Any]) -> None:
    data = base.model_dump()
    data.update(overrides)
    try:
        Settings.model_validate(data)
    except PydanticValidationError as exc:
        first = exc.errors()[0] if exc.errors() else {}
        raise ValidationError(str(first.get("msg", "Некорректное значение"))) from exc
